//
//  ViewController.swift
//  komal
//
// 
//  Copyright © 2017 komalpreet kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var pass: UITextField!
    @IBAction func loginAdd(_ sender: UIButton) {
        var u=Demo.email
        var p=Demo.pass
        var status=0
        var index=""
        for i in 0..<u.count{
            if(u[i]==email.text!){
                status=1
                index=String(i)
            }
        }
        if(status==1){
            var ind=Int(index)!
            if(p[ind]==pass.text!){
                let home:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "home") as? mapViewController)!
                self.navigationController?.pushViewController(home, animated: true)
                
            }else{
                print("Password is wrong")
            }
        }else{
            print("Username is wrong")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if(Demo.logStatus==0){
            Demo.name=["kc","pc"]
            Demo.email=["komalpreet@gmail.com","pawanpreet@gmail.com"]
            Demo.mob=["9988776655","123456789"]
            Demo.pass=["komal","pawan"]
            Demo.logStatus=1
        }
        navigationItem.hidesBackButton=true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

