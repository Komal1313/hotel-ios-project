//
//  paymethod.swift
//  komal
//
//  Created by Komalpreet Kaur on 2017-11-11.
//  Copyright © 2017 komalpreet kaur. All rights reserved.
//

import Foundation
import UIKit
class Payviewcontroller: UIViewController {
    
    @IBOutlet weak var amntfeld: UITextField!
    var amountToDisplay = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        amntfeld.text = amountToDisplay
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Back(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }






}
