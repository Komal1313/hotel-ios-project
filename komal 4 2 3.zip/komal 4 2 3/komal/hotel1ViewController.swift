//
//  hotel1ViewController.swift
//  komal
//
//  Created by ranjeet kaur on 2017-11-08.
//  Copyright © 2017 komalpreet kaur. All rights reserved.
//

import UIKit

class hotel1ViewController: UIViewController, UITextFieldDelegate {
    var status1:Int = 0
    var status2:Int = 0
    var status3:Int = 0
    var status4:Int = 0
    var status5:Int = 0
    
    @IBOutlet weak var firstB: UIButton!
    @IBOutlet weak var secondB: UIButton!
    @IBOutlet weak var thirdB: UIButton!
    @IBOutlet weak var fourtB: UIButton!
    @IBOutlet weak var fifthB: UIButton!
    
    
    @IBOutlet weak var total: UITextField!
    var BoxOn = UIImage(named: "boxchk")
    var BoxOff = UIImage(named: "boxunchk")
    
    var isBoxClicked: Bool!



    override func viewDidLoad() {
        super.viewDidLoad()
        isBoxClicked = false
        view.backgroundColor = UIColor.white

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func button1(_ sender: UIButton) {
        if isBoxClicked == true{
            isBoxClicked = false
            status1=0
        }else{
            isBoxClicked = true
            
            status1=1
        }
        
        if isBoxClicked == true{
            firstB.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            firstB.setImage(BoxOff, for: UIControlState.normal)
        }
        
    }
    
    @IBAction func button2(_ sender: UIButton) {
        if isBoxClicked == true{
            isBoxClicked = false
            status2=0
        }else{
            isBoxClicked = true
            
            status2=1
        }
        
        if isBoxClicked == true{
            secondB.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            secondB.setImage(BoxOff, for: UIControlState.normal)
        }
        
    }
    
    @IBAction func button3(_ sender: UIButton) {
        if isBoxClicked == true{
            isBoxClicked = false
            status3=0
        }else{
            isBoxClicked = true
            
            status3=1
        }
        
        if isBoxClicked == true{
            thirdB.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            thirdB.setImage(BoxOff, for: UIControlState.normal)
        }
        
    }
    
    
    @IBAction func button4(_ sender: UIButton) {
        if isBoxClicked == true{
            isBoxClicked = false
            status4=0
        }else{
            isBoxClicked = true
            
            status4=1
        }
        
        if isBoxClicked == true{
            fourtB.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            fourtB.setImage(BoxOff, for: UIControlState.normal)
        }
        
    }
    
    @IBAction func button5(_ sender: UIButton) {
        
        if isBoxClicked == true{
            isBoxClicked = false
            status5=0
        }else{
            isBoxClicked = true
            
            status5=1
        }
        
        if isBoxClicked == true{
            fifthB.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            fifthB.setImage(BoxOff, for: UIControlState.normal)
        }
    }
    
    @IBAction func submit(_ sender: UIButton) {
        var totalamount:Int=0
        if(status1==1){
            totalamount=totalamount+500
            
        }
        
        if(status2==1){
            totalamount=totalamount+1000
            
        }
        if(status3==1){
            totalamount=totalamount+300
            
        }
        if(status4==1){
            totalamount=totalamount+400
            
        }
        if(status5==1){
            totalamount=totalamount+800
            
        }
        
        print(totalamount)
        total.text = "\(totalamount)"
    }
    
    @IBAction func proceedanyway(_ sender: UIButton) {
       
            performSegue(withIdentifier: "hipaym", sender: self)
       
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "hipaym")
        {
            let destVC = segue.destination as!
            Hipaymethod
            destVC.amountDisplay = total.text!
            
        }

}
}
