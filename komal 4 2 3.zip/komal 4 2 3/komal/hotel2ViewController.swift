//
//  hotel2ViewController.swift
//  komal
//
//  Created by ranjeet kaur on 2017-11-08.
//  Copyright © 2017 komalpreet kaur. All rights reserved.
//

import UIKit

class hotel2ViewController: UIViewController, UITextFieldDelegate {
    var status6:Int=0
    var status7:Int=0
    var status8:Int=0
    var status9:Int=0
    var status10:Int=0
    

    @IBOutlet weak var firstbtn: UIButton!
    @IBOutlet weak var secondbtn: UIButton!
    @IBOutlet weak var thirdbtn: UIButton!
    
    @IBOutlet weak var fifthbtn: UIButton!
    @IBOutlet weak var fourhbtn: UIButton!
    @IBOutlet weak var rasultamount: UITextField!
    var BoxOn = UIImage(named: "boxchk")
    var BoxOff = UIImage(named: "boxunchk")
    
    var isBoxClicked: Bool!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        isBoxClicked = false
        view.backgroundColor = UIColor.white

        // Do any additional setup after loading the view.
    }

    
    
    @IBAction func btn1(_ sender: UIButton) {
        if isBoxClicked == true{
            isBoxClicked = false
            status6=0
        }else{
            isBoxClicked = true
            
            status6=1
        }
        
        if isBoxClicked == true{
            firstbtn.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            firstbtn.setImage(BoxOff, for: UIControlState.normal)
        }

    }
    
    @IBAction func butn2(_ sender: UIButton) {
        if isBoxClicked == true{
            isBoxClicked = false
            status7=0
        }else{
            isBoxClicked = true
            
            status7=1
        }
        
        if isBoxClicked == true{
            secondbtn.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            secondbtn.setImage(BoxOff, for: UIControlState.normal)
        }

    }
    
    @IBAction func btn33(_ sender: UIButton) {
        if isBoxClicked == true{
            isBoxClicked = false
            status8=0
        }
        else{
            isBoxClicked = true
            
            status8=1
        }
        
        if isBoxClicked == true
        {
            thirdbtn.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            thirdbtn.setImage(BoxOff, for: UIControlState.normal)
        }

    }
    
    @IBAction func btn4(_ sender: UIButton) {
        if isBoxClicked == true{
            isBoxClicked = false
            status9=0
        }else{
            isBoxClicked = true
            
            status9=1
        }
        
        if isBoxClicked == true{
            fourhbtn.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            fourhbtn.setImage(BoxOff, for: UIControlState.normal)
        }
        
    }
    
    
    @IBAction func btn5(_ sender: UIButton) {
        
        if isBoxClicked == true{
            isBoxClicked = false
            status10=0
        }else{
            isBoxClicked = true
            
            status10=1
        }
        
        if isBoxClicked == true{
            fifthbtn.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
          fifthbtn.setImage(BoxOff, for: UIControlState.normal)
        }
    }
    
    
    
    
    
    
    @IBAction func submit2(_ sender: UIButton) {
    
    var Bill:Int=0
        if(status6==1){
            Bill=Bill+700
            
        }
        
        if(status7==1){
            Bill=Bill+500
            
        }
        if(status8==1){
            Bill=Bill+300
            
        }
        if(status9==1){
            Bill=Bill+500
            
        }
        if(status10==1){
            Bill=Bill+600
            
        }
        print(Bill)
        rasultamount.text = "\(Bill)"
        
    }
    
    @IBAction func proceed(_ sender: UIButton) {
        performSegue(withIdentifier: "pay", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "pay")
        {
            let destVC = segue.destination as!
         Payviewcontroller
            destVC.amountToDisplay = rasultamount.text!
            
        }
    }
    

    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
