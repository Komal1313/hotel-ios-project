//
//  paymethod.swift
//  komal
//
//  Created by Komalpreet Kaur on 2017-11-11.
//  Copyright © 2017 komalpreet kaur. All rights reserved.
//

import Foundation
import UIKit
class Register: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func register(_ sender: UIButton) {
        if(name.text!=="" || email.text!=="" || password.text!=="" || mob.text!==""){
            print("Username is required")
        }else{
            Demo.name.append(name.text!)
            Demo.email.append(email.text!)
            Demo.mob.append(mob.text!)
            Demo.pass.append(password.text!)
            print("Data Added")
            name.text=""
            email.text=""
            mob.text=""
            password.text=""
            
            
        }
        
        
    }
    @IBOutlet weak var mob: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var email: UITextField!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

