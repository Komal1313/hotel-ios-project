//
//  MyStatic.swift
//  komal
//
//  Created by Kiran Hans on 11/13/17.
//  Copyright © 2017 komalpreet kaur. All rights reserved.
//

import Foundation
class Demo{
    static var name=[String]()
    static var email=[String]()
    static var mob=[String]()
    static var pass=[String]()
    static var logStatus=0
}
