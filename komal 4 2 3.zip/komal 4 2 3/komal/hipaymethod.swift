//
//  hipaymethod.swift
//  komal
//
//  Created by Kiran Hans on 11/12/17.
//  Copyright © 2017 komalpreet kaur. All rights reserved.
//

import Foundation
import UIKit
class Hipaymethod: UIViewController {
    
    @IBOutlet weak var amMy: UITextField!
    var amountDisplay = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        print("xyz")
        amMy.text = amountDisplay
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Back(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
}
