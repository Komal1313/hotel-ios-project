//
//  mapViewController.swift
//  komal
//
//  Created by ranjeet kaur on 2017-11-03.
//  Copyright © 2017 komalpreet kaur. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Foundation
class mapViewController: UIViewController,CLLocationManagerDelegate, MKMapViewDelegate, UITextFieldDelegate
 {
    
    @IBOutlet weak var map: MKMapView!
     var mapManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton=true
         map.isZoomEnabled = true

        // Do any additional setup after loading the view.
        mapManager.delegate = self                            // ViewController is the "owner" of the map.
        mapManager.desiredAccuracy = kCLLocationAccuracyBest  // Define the best location possible to be used in app.
        mapManager.requestWhenInUseAuthorization()            // The feature will not run in background
        mapManager.startUpdatingLocation()                    // Continuously geo-position update
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // The array locations stores all the user's positions, and the position 0 is the most recent one
        let location = locations[0]
        
        // Here we define the map's zoom. The value 0.01 is a pattern
        let zoom:MKCoordinateSpan = MKCoordinateSpanMake(0.9, 0.9)
        
        // Store latitude and longitude received from smartphone
        let myLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        let location1:CLLocationCoordinate2D = CLLocationCoordinate2DMake(44.3894, -79.6903)
        let location2:CLLocationCoordinate2D = CLLocationCoordinate2DMake(43.7315, -79.7624)
        
        // Based on myLocation and zoom define the region to be shown on the screen
        let region:MKCoordinateRegion = MKCoordinateRegionMake(myLocation, zoom)
        // let region1:MKCoordinateRegion = MKCoordinateRegionMake(location1, zoom)
        //let region2:MKCoordinateRegion = MKCoordinateRegionMake(location2,zoom)
        
        // Setting the map itself based previous set-up
        map.setRegion(region, animated: true)
        // map.setRegion(region1, animated: true)
        // map.setRegion(region2, animated: true)
        
        // Showing the blue dot in a map
        map.showsUserLocation = true
        
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        
        let room1 = MKPointAnnotation()
        room1.coordinate = location1
        room1.title = "hotel1"
        room1.subtitle = "rooms avaliable"
        
        let room2 = MKPointAnnotation()
        room2.coordinate = location2
        room2.title = "hotel2"
        room2.subtitle = "rooms avaliable"
        map.addAnnotation(room1)
        map.addAnnotation(room2)
        
    }
    
}



    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


